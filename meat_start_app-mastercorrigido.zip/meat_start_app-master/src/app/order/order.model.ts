class Order{
  public constructor(
    public address: string,
    public number: number,
    public optionalAddress: string,
    public paymanetOption: string,
    public orderItems : OrderItem[] = []
  ){}
}

class OrderItem{
  constructor(public quantity:number, public menuId: string){}
}

export{Order, OrderItem}
