# Aplicativo Angular 4 - Meat Start App
## Construindo Aplicações Web Com o Novo Angular (4, 5 e 6)
### Plataforma Acadêmica UDEMY
### Autor e criador : Tarso Bessa
#### Utilizando esse projeto apenas para fins de aprendizagem e adquirir conhecimentos no framework Angular
